﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EjemploPrototipo
{
    //Establecer la herencia de AutoPrototipo
    public class DSPrototipo : AutoPrototipo
    {
        //Emplear todos los métodos provenientes de la clase abstracta
        public override AutoPrototipo Clonar()
        {
            //El método MemberwiseClone devuelve una copia superficial del objeto de tipo DSPrototipo
            return (DSPrototipo)this.MemberwiseClone();
        }

        //Muestra la información del auto DS
        public override string VerAuto()
        {
            return "DS: " + getModelo() + " | Color: " + getColor();
        }
    }
}
